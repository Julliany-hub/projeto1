export interface Cardapio{
    prato:string
    preco:number
    imagem:string
}